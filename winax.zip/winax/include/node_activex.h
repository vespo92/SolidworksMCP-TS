#pragma once

// Include all the relevant definitions for use of the library code in a dependency.
// Note that this does use the namespaces v8 and node in the current configuration

#include "../src/stdafx.h"
#include "../src/disp.h"
#include "../src/utils.h"
