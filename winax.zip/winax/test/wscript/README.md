# WScript JScript samples

Here we have a number of .js files taken from available tutorials and samples just as is. Our goal is to demonstrante that `nodewscript` may be used to launch them without any modification.

`wmi.js` https://www.activexperts.com/admin/scripts/wmi/jscript/0383/

`enumerator.js` https://gist.github.com/mlhaufe/1569247

